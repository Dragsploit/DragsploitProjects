﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WeAreDevs_API;
using System.Diagnostics;
using System.Net;
using System.IO;
using System.Linq.Expressions;
using System.Runtime.InteropServices;

namespace tp
{
    public partial class Form1 : Form
    {
        ExploitAPI api = new ExploitAPI();

        //Gives form round edges
        [DllImport("Gdi32.dll", EntryPoint = "CreateRoundRectRgn")]
        public static extern IntPtr CreateRoundRectRgn
(
   int nLeftRect,     // x-coordinate of upper-left corner
   int nTopRect,      // y-coordinate of upper-left corner
   int nRightRect,    // x-coordinate of lower-right corner
   int nBottomRect,   // y-coordinate of lower-right corner
   int nWidthEllipse, // height of ellipse
   int nHeightEllipse // width of ellipse
);


        public Form1()
        {
            InitializeComponent();

            //Gives form rounded edges
            this.FormBorderStyle = FormBorderStyle.None;
            Region = System.Drawing.Region.FromHrgn(CreateRoundRectRgn(0, 0, Width, Height, 20, 20));


        }



        //Auto Attach function
        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked == true)
            {
                if (Process.GetProcessesByName("RobloxPlayerBeta").Length != 0)
                {
                    api.LaunchExploit();
                    enabledinroblox.Start();
                }
                else
                {
                    robloxcheck.Start();
                    timer1.Start();
                }
                
            }
            if (checkBox1.Checked == false)
            {
                inject.Stop();
                robloxcheck.Stop();
                timer1.Stop();
                enabledinroblox.Stop();
            }
        }

        private void inject_Tick(object sender, EventArgs e)
        {
            inject.Stop();
            robloxcheck.Stop();  
            if (Process.GetProcessesByName("RobloxPlayerBeta").Length != 0)
            {
                api.LaunchExploit();
            }
            else
            {
                MessageBox.Show("API failed to auto-attach", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        

        private void robloxcheck_Tick(object sender, EventArgs e)
        {
            if (Process.GetProcessesByName("RobloxPlayerBeta").Length != 0)
            {
                inject.Start();
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (Process.GetProcessesByName("RobloxPlayerBeta").Length != 1)
            {
                robloxcheck.Start();
            }
        }

        //This is optional but its useful incase they enable Auto-Injection while ROBLOX is running
        private void enabledinroblox_Tick(object sender, EventArgs e)
        {
            if (Process.GetProcessesByName("RobloxPlayerBeta").Length != 1)
            {
                enabledinroblox.Stop();
                robloxcheck.Start();
                timer1.Start();
            }
        }

        //EXECUTOR Functions

        //execute
        private void button1_Click(object sender, EventArgs e)
        {
            if (Process.GetProcessesByName("RobloxPlayerBeta").Length != 0)
            {
                string txt = textBox1.Text;
                api.SendLuaScript(txt);
            }
            else
            {
                MessageBox.Show("Inject before executing", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            
        }

        //clear
        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
        }


        //Make form moveaable
        public const int WM_NCLBUTTONDOWN = 0xA1;
        public const int HT_CAPTION = 0x2;

        [System.Runtime.InteropServices.DllImport("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);
        [System.Runtime.InteropServices.DllImport("user32.dll")]
        public static extern bool ReleaseCapture();
        private void label1_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
            }
        }

        //Close application
        private void button3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        //Topmost
        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox2.Checked)
            {
                TopMost = true;
            }
            else
            {
                TopMost = false;
            }
        }

       
    }
}
